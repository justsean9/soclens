from __future__ import annotations

from abc import abstractmethod
from typing import Any, Callable, ClassVar

from sigma.processing.pipeline import ProcessingPipeline


class Pipeline:
    """
    Base class for all pipelines. This class acts as a class decorator
    to register existing pipelines, and also as a base class for all
    the new pipelines. The reasoning behind this is discussed in:
    https://github.com/SigmaHQ/pySigma/discussions/110#discussioncomment-6179682
    """

    _instance: ClassVar[Pipeline | None] = None

    def __init__(
        self,
        func: Callable[[], ProcessingPipeline] | None = None,
    ):
        """
        Initialize the pipeline. If the function is set, then it is a class decorator.
        Otherwise, it is an inherited class, so we return the class itself.

        Keyword Arguments:
            func (Callable[[], ProcessingPipeline] | None): The function to be
                decorated. If None, the class is inherited. Defaults to None.
        """
        self.func = func

    def __call__(self, *args: list[Any], **kwargs: dict[str, Any]) -> Any:
        """
        When the class is called, we call the function if set,
        otherwise we return the class itself.
        """
        apply_method = getattr(self, "apply", None)
        if callable(apply_method) and not getattr(apply_method, "__isabstractmethod__", False):
            return apply_method(*args, **kwargs)
        return self.func(*args, **kwargs) if self.func is not None else self

    def __new__(cls, *args: list[Any], **kwargs: dict[str, Any]) -> "Pipeline":
        """
        Use the singleton pattern for subclasses to ensure that only one instance of
        each class is created. This is necessary to ensure that the pipelines are
        registered only once if the class is inherited.

        When used as a decorator (``@Pipeline``), every decorated function gets its own
        instance. Sharing one instance would make every decorated pipeline alias the
        last decorated function.

        Args:
            cls ([type]): The class itself.
            *args: The arguments to be passed to the class constructor.

        Keyword Arguments:
            **kwargs: The keyword arguments to be passed to the class constructor.

        Returns:
            Pipeline: The class instance.
        """
        if cls is Pipeline:
            return super(Pipeline, cls).__new__(cls)
        # Look up the singleton on the class itself, not inherited from a base class.
        instance: Pipeline | None = cls.__dict__.get("_instance")
        if instance is None:
            instance = super(Pipeline, cls).__new__(cls)
            cls._instance = instance
        return instance

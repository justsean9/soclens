import hashlib
import re
from sigma.conversion.state import ConversionState
from sigma.modifiers import SigmaRegularExpression
from sigma.correlations import (
    SigmaCorrelationRule,
    CorrelationConditionAND,
    CorrelationConditionOR,
)
from sigma.rule import SigmaRule, SigmaDetection
from sigma.conversion.base import TextQueryBackend, DeferredQueryExpression
from sigma.conversion.deferred import DeferredTextQueryExpression
from sigma.conditions import (
    ConditionFieldEqualsValueExpression,
    ConditionOR,
    ConditionAND,
    ConditionNOT,
    ConditionItem,
)
from sigma.types import SigmaCompareExpression, SigmaString
from sigma.exceptions import SigmaFeatureNotSupportedByBackendError, SigmaError
from sigma.pipelines.splunk.splunk import (
    splunk_sysmon_process_creation_cim_mapping,
    splunk_windows_registry_cim_mapping,
    splunk_windows_file_event_cim_mapping,
    splunk_web_proxy_cim_mapping,
    splunk_dns_cim_mapping,
)
import sigma
from typing import (
    Any,
    Callable,
    ClassVar,
    Dict,
    List,
    Optional,
    Pattern,
    Set,
    Tuple,
    Union,
)

# Characters that must never appear in a field name that is interpolated into SPL. Field names
# are emitted either unquoted or wrapped in quotes without escaping, so any of these would allow
# rule content to terminate the enclosing syntax element and inject SPL (e.g. a pipe followed by
# an arbitrary command) or break out of a savedsearches.conf line.
_unsafe_identifier_re: Pattern = re.compile(r"[\"'`\\|\x00-\x1f\x7f]")
# Field names used unquoted in deferred pipeline commands (regex, rex, where).
_deferred_field_re: Pattern = re.compile(r"^[\w.\-]+$")
# Field names that can be emitted unquoted in a `| table` command.
_table_field_re: Pattern = re.compile(r"^[\w.*\-]+$")
# Line breaks that end a savedsearches.conf line.
_line_break_re: Pattern = re.compile(r"\r\n|\r|\n")


def check_identifier(
    name: Optional[str], kind: str = "field name", source: Any = None
) -> Optional[str]:
    """Reject identifiers that could break out of the SPL syntax element they are placed in."""
    if name is not None and _unsafe_identifier_re.search(name):
        raise SigmaFeatureNotSupportedByBackendError(
            f"Splunk backend does not support {kind} {name!r}: it contains a quote, backslash, "
            "backtick, pipe or control character",
            source=source,
        )
    return name


def check_deferred_field(name: Optional[str], source: Any = None) -> Optional[str]:
    """Field names in deferred regex/rex/where commands are emitted unquoted."""
    if name is not None and not _deferred_field_re.match(name):
        raise SigmaFeatureNotSupportedByBackendError(
            f"Splunk backend does not support field name {name!r} in regular expression or "
            "field reference matching: only letters, digits, '_', '.' and '-' are allowed",
            source=source,
        )
    return name


def table_fields(fields: List[str], quote: str, source: Any = None) -> List[str]:
    """Validate `fields:` of a rule and quote those that can't be emitted bare."""
    result = []
    for field in fields:
        check_identifier(field, "table field", source)
        result.append(field if _table_field_re.match(field) else quote + field + quote)
    return result


class SplunkDeferredRegularExpression(DeferredTextQueryExpression):
    template = 'regex {field}{op}"{value}"'
    operators = {
        True: "!=",
        False: "=",
    }
    default_field = "_raw"


class SplunkDeferredORRegularExpression(DeferredTextQueryExpression):
    field_counts = {}
    default_field = "_raw"
    max_match_group_name_len = 32
    operators = {
        True: "!=",
        False: "=",
    }

    def __init__(self, state, field, arg) -> None:
        self.add_field(field)
        field_condition = self.get_field_condition(field)
        field_match = self.get_field_match(field)
        self.template = 'rex field={{field}} "(?<{field_match}>{{value}})"\n| eval {field_condition}=if(isnotnull({field_match}), "true", "false")'.format(
            field_match=field_match, field_condition=field_condition
        )
        return super().__init__(state, field, arg)

    @staticmethod
    def clean_field(field):
        # splunk does not allow dots in regex group, so we need to clean variables
        return re.sub(".*\\.", "", field)

    @classmethod
    def add_field(cls, field):
        cls.field_counts[field] = (
            cls.field_counts.get(field, 0) + 1
        )  # increment the field count

    @classmethod
    def get_field_suffix(cls, field):
        index_suffix = cls.field_counts.get(field, "")
        if index_suffix == 1:
            index_suffix = ""
        return index_suffix

    @classmethod
    def construct_field_variable(cls, field, variable):
        cleaned_field = cls.clean_field(field)
        index_suffix = cls.get_field_suffix(field)
        return f"{cleaned_field}{variable}{index_suffix}"

    @classmethod
    def construct_field_match(cls, field):
        cleaned_field = cls.clean_field(field)
        suffix = f"Match{cls.get_field_suffix(field)}"
        field_match = f"{cleaned_field}{suffix}"

        if len(field_match) <= cls.max_match_group_name_len:
            return field_match

        digest = hashlib.blake2s(cleaned_field.encode()).hexdigest()[:8]
        prefix_len = max(
            cls.max_match_group_name_len - len(suffix) - len(digest),
            0,
        )
        return f"{cleaned_field[:prefix_len]}{digest}{suffix}"

    @classmethod
    def get_field_match(cls, field):
        return cls.construct_field_match(field)

    @classmethod
    def get_field_condition(cls, field):
        return cls.construct_field_variable(field, "Condition")

    @classmethod
    def get_all_condition_fields(cls):
        """Return the set of all condition field names created by deferred OR regex expressions."""
        result = set()
        for field, count in cls.field_counts.items():
            cleaned = cls.clean_field(field)
            for i in range(1, count + 1):
                suffix = "" if i == 1 else str(i)
                result.add(f"{cleaned}Condition{suffix}")
        return result

    @classmethod
    def reset(cls):
        cls.field_counts = {}


class SplunkDeferredFieldRefExpression(DeferredTextQueryExpression):
    template = "where {op}'{field}'='{value}'"
    operators = {
        True: "NOT ",
        False: "",
    }
    default_field = "_raw"


class SplunkBackend(TextQueryBackend):
    """Splunk SPL backend."""

    name: ClassVar[str] = (
        "Splunk SPL & tstats data model queries"  # A descriptive name of the backend
    )
    formats: ClassVar[Dict[str, str]] = (
        {  # Output formats provided by the backend as name -> description mapping. The name should match to finalize_output_<name>.
            "default": "Plain SPL queries",
            "savedsearches": "Plain SPL in a savedsearches.conf file",
            "data_model": "Data model queries with tstats",
        }
    )
    requires_pipeline: ClassVar[bool] = (
        True  # Does the backend requires that a processing pipeline is provided?
    )

    precedence: ClassVar[Tuple[ConditionItem, ConditionItem, ConditionItem]] = (
        ConditionNOT,
        ConditionAND,
        ConditionOR,
    )
    group_expression: ClassVar[str] = "({expr})"

    bool_values = {True: "true", False: "false"}
    or_token: ClassVar[str] = "OR"
    and_token: ClassVar[str] = " "
    not_token: ClassVar[str] = "NOT"
    eq_token: ClassVar[str] = "="

    field_quote: ClassVar[str] = '"'
    field_quote_pattern: ClassVar[Pattern] = re.compile(r"^[\w.]+$")

    str_quote: ClassVar[str] = '"'
    escape_char: ClassVar[str] = "\\"
    wildcard_multi: ClassVar[str] = "*"
    wildcard_single: ClassVar[str] = "*"
    add_escaped: ClassVar[str] = "\\"

    re_expression: ClassVar[str] = "{regex}"
    re_escape_char: ClassVar[str] = "\\"
    re_escape: ClassVar[Tuple[str]] = ('"',)

    cidr_expression: ClassVar[str] = '{field}="{value}"'

    compare_op_expression: ClassVar[str] = "{field}{operator}{value}"
    compare_operators: ClassVar[Dict[SigmaCompareExpression.CompareOperators, str]] = {
        SigmaCompareExpression.CompareOperators.LT: "<",
        SigmaCompareExpression.CompareOperators.LTE: "<=",
        SigmaCompareExpression.CompareOperators.GT: ">",
        SigmaCompareExpression.CompareOperators.GTE: ">=",
    }

    field_equals_field_expression: ClassVar[str] = "{field2}"
    field_null_expression: ClassVar[str] = "NOT {field}=*"

    convert_or_as_in: ClassVar[bool] = True
    convert_and_as_in: ClassVar[bool] = False
    in_expressions_allow_wildcards: ClassVar[bool] = True
    field_in_list_expression: ClassVar[str] = "{field} {op} ({list})"
    or_in_operator: ClassVar[Optional[str]] = "IN"
    list_separator: ClassVar[str] = ", "
    field_exists_expression: ClassVar[str] = "{field}=*"
    field_not_exists_expression: ClassVar[str] = "NOT {field}=*"

    unbound_value_str_expression: ClassVar[str] = "{value}"
    unbound_value_num_expression: ClassVar[str] = "{value}"
    unbound_value_re_expression: ClassVar[str] = "{value}"

    deferred_start: ClassVar[str] = "\n| "
    deferred_separator: ClassVar[str] = "\n| "
    deferred_only_query: ClassVar[str] = "*"

    # Pattern matching a leading field=value term in a query string.
    _field_eq_val_re: ClassVar[Pattern] = re.compile(
        r'([\w.]+)(?:="[^"]*"|=[^\s")]+)\s*'
    )

    # Correlations
    correlation_methods: ClassVar[Dict[str, str]] = {
        "stats": "Correlation using stats command (more efficient, static time window)",
        # "transaction": "Correlation using transaction command (less efficient, sliding time window",
    }
    default_correlation_method: ClassVar[str] = "stats"
    default_correlation_query: ClassVar[str] = {
        "stats": "{search}\n\n{aggregate}\n\n{condition}"
    }

    correlation_search_single_rule_expression: ClassVar[str] = "{query}"
    correlation_search_multi_rule_expression: ClassVar[str] = "| multisearch\n{queries}"
    correlation_search_multi_rule_query_expression: ClassVar[str] = (
        '[ search {query} | eval event_type="{ruleid}"{normalization} ]'
    )
    correlation_search_multi_rule_query_expression_joiner: ClassVar[str] = "\n"

    correlation_search_field_normalization_expression: ClassVar[str] = (
        " | rename {field} as {alias}"
    )
    correlation_search_field_normalization_expression_joiner: ClassVar[str] = ""

    event_count_aggregation_expression: ClassVar[Dict[str, str]] = {
        "stats": "| bin _time span={timespan}\n| stats count as event_count{fields} by _time{groupby}",
    }
    value_count_aggregation_expression: ClassVar[Dict[str, str]] = {
        "stats": "| bin _time span={timespan}\n| stats dc({field}) as value_count{fields} by _time{groupby}",
    }
    temporal_aggregation_expression: ClassVar[Dict[str, str]] = {
        "stats": "| bin _time span={timespan}\n| stats dc(event_type) as event_type_count{fields} by _time{groupby}",
    }
    temporal_extended_aggregation_expression: ClassVar[Dict[str, str]] = {
        "stats": "| bin _time span={timespan}\n| stats values(event_type) as event_types{fields} by _time{groupby}",
    }

    correlation_fields_expression: ClassVar[Dict[str, str]] = {"stats": "{fields}"}
    correlation_fields_field_expression: ClassVar[Dict[str, str]] = {
        "stats": " values({field}) as {field}"
    }
    correlation_fields_field_expression_joiner: ClassVar[Dict[str, str]] = {"stats": ""}

    timespan_mapping: ClassVar[Dict[str, str]] = {
        "M": "mon",
    }

    groupby_expression: ClassVar[Dict[str, str]] = {"stats": " {fields}"}
    groupby_field_expression: ClassVar[Dict[str, str]] = {"stats": "{field}"}
    groupby_field_expression_joiner: ClassVar[Dict[str, str]] = {"stats": " "}

    event_count_condition_expression: ClassVar[Dict[str, str]] = {
        "stats": "| search event_count {op} {count}"
    }
    value_count_condition_expression: ClassVar[Dict[str, str]] = {
        "stats": "| search value_count {op} {count}"
    }
    temporal_condition_expression: ClassVar[Dict[str, str]] = {
        "stats": "| search event_type_count {op} {count}"
    }
    temporal_extended_condition_expression: ClassVar[dict[str, str]] = {
        "stats": "| search {extended_condition}"
    }

    extended_correlation_condition_rule_reference_expression: ClassVar[
        dict[str, str]
    ] = {"stats": 'event_types="{ruleid}"'}

    # Splunk stats/tstats functions allowed in the `tstats_aggregations` data model setting.
    data_model_aggregation_functions: ClassVar[Set[str]] = {
        "avg",
        "dc",
        "distinct_count",
        "earliest",
        "estdc",
        "first",
        "last",
        "latest",
        "list",
        "max",
        "mean",
        "median",
        "min",
        "mode",
        "range",
        "stdev",
        "stdevp",
        "sum",
        "sumsq",
        "values",
        "var",
        "varp",
    }
    _data_model_identifier_re: ClassVar[Pattern] = re.compile(r"^[\w.]+$")
    _data_model_span_re: ClassVar[Pattern] = re.compile(
        r"^\d+(?:s|sec|secs|second|seconds|m|min|mins|minute|minutes|h|hr|hrs|hour|hours|d|day|days|mon|mont|months)?$"
    )

    def __init__(
        self,
        processing_pipeline: Optional[
            "sigma.processing.pipeline.ProcessingPipeline"
        ] = None,
        collect_errors: bool = False,
        min_time: str = "-30d",
        max_time: str = "now",
        summariesonly: bool = False,
        query_settings: Callable[[SigmaRule], Dict[str, str]] = lambda x: {},
        output_settings: Dict = {},
        **kwargs,
    ):
        super().__init__(processing_pipeline, collect_errors, **kwargs)
        self.summariesonly = summariesonly
        self.query_settings = query_settings
        self.output_settings = {
            "dispatch.earliest_time": min_time,
            "dispatch.latest_time": max_time,
        }
        self.output_settings.update(output_settings)

    @staticmethod
    def _generate_settings(settings):
        """Format a settings dict into newline separated k=v string. Escape multi-line values."""
        output = ""
        for k, v in settings.items():
            # Normalize CRLF to LF and strip bare CR so they don't become continuation lines
            v = v.replace("\r\n", "\n").replace("\r", "")
            output += f"\n{k} = " + " \\\n".join(
                v.split("\n")
            )  # cannot use \ in f-strings
        return output

    def escape_and_quote_field(self, field_name: str) -> str:
        """Field names are quoted but not escaped: reject names that could break out of the quotes."""
        check_identifier(field_name)
        return super().escape_and_quote_field(field_name)

    def compare_precedence(self, outer, inner) -> bool:
        """
        Always group an AND nested inside an OR (and, via the precedence tuple, an OR nested
        inside an AND).

        The Splunk `search` command documents its Boolean evaluation order as parentheses,
        NOT, OR, AND, i.e. OR binds tighter than the implicit AND, which is the opposite of
        the order used by `eval`/`where`. Grouping every mixed AND/OR nesting makes the
        emitted query independent of which of the two orders applies.
        """
        if isinstance(outer, (ConditionOR, CorrelationConditionOR)) and isinstance(
            inner, (ConditionAND, CorrelationConditionAND)
        ):
            return False
        return super().compare_precedence(outer, inner)

    @staticmethod
    def _is_pipeline_filter(cond: ConditionFieldEqualsValueExpression) -> bool:
        """
        Return True if cond can be applied as its own pipeline command after the main search.

        Consecutive pipeline commands are ANDed, and only a deferred expression that is the
        direct operand of a NOT is negated. The condition qualifies only if it is negated
        directly at most and every other enclosing operator is an AND.
        """
        chain = cond.parent_chain_condition_classes()
        if chain and chain[0] is ConditionNOT:
            chain = chain[1:]
        return all(c is ConditionAND for c in chain)

    def convert_condition_and(
        self,
        cond: ConditionAND,
        state: "sigma.conversion.state.ConversionState",
    ) -> Union[str, DeferredQueryExpression, None]:
        deferred_count = len(state.deferred)
        result = super().convert_condition_and(cond, state)
        if (
            result is None
            and len(state.deferred) > deferred_count
            and not cond.parent_chain_condition_classes()
        ):
            # Every operand of the top-level AND was moved to a pipeline command, so the
            # main search has to match everything.
            return self.deferred_only_query
        return result

    def convert_condition_field_eq_val_re(
        self,
        cond: ConditionFieldEqualsValueExpression,
        state: "sigma.conversion.state.ConversionState",
    ) -> SplunkDeferredRegularExpression:
        """
        Defer regular expression matching to pipelined regex command after main search expression.

        If the regular expression is part of an OR or of a negated group, a pipelined regex
        command cannot express it. It is evaluated by rex and eval commands instead, and the
        main search expression is applied afterwards with a search command.
        """
        check_deferred_field(cond.field, cond.source)

        if not self._is_pipeline_filter(cond):
            # adding the deferred to the state
            SplunkDeferredORRegularExpression(
                state,
                cond.field,
                super().convert_condition_field_eq_val_re(cond, state),
            ).postprocess(None, cond)

            cond_true = ConditionFieldEqualsValueExpression(
                SplunkDeferredORRegularExpression.get_field_condition(cond.field),
                SigmaString("true"),
            )
            # returning fieldX=true
            return super().convert_condition_field_eq_val_str(cond_true, state)
        return SplunkDeferredRegularExpression(
            state, cond.field, super().convert_condition_field_eq_val_re(cond, state)
        ).postprocess(None, cond)

    def convert_condition_field_eq_field(
        self,
        cond: ConditionFieldEqualsValueExpression,
        state: "sigma.conversion.state.ConversionState",
    ) -> SplunkDeferredFieldRefExpression:
        """Defer FieldRef matching to pipelined with `where` command after main search expression."""
        check_deferred_field(cond.field, cond.source)
        check_deferred_field(cond.value.field, cond.source)
        if cond.parent_condition_chain_contains(ConditionOR):
            raise SigmaFeatureNotSupportedByBackendError(
                "ORing FieldRef matching is not yet supported by Splunk backend",
                source=cond.source,
            )
        if not self._is_pipeline_filter(cond):
            raise SigmaFeatureNotSupportedByBackendError(
                "Negating a group with FieldRef matching is not yet supported by Splunk backend",
                source=cond.source,
            )
        return SplunkDeferredFieldRefExpression(
            state, cond.field, super().convert_condition_field_eq_field(cond, state)
        ).postprocess(None, cond)

    def finish_query(
        self,
        rule: Union[SigmaRule, SigmaCorrelationRule],
        query: Union[str, DeferredQueryExpression],
        state: ConversionState,
    ) -> Union[str, DeferredQueryExpression]:
        if isinstance(query, DeferredQueryExpression):
            query = self.deferred_only_query

        if state.has_deferred():
            deferred_regex_or_expressions = []
            remaining_deferred = []

            for deferred_expression in state.deferred:
                if isinstance(deferred_expression, SplunkDeferredORRegularExpression):
                    deferred_regex_or_expressions.append(
                        deferred_expression.finalize_expression()
                    )
                else:
                    remaining_deferred.append(deferred_expression)

            if deferred_regex_or_expressions:
                # Collect all condition field names created by deferred OR
                # regex expressions before resetting, so finalize methods
                # can identify which query parts don't depend on them.
                state.processing_state["deferred_or_condition_fields"] = (
                    SplunkDeferredORRegularExpression.get_all_condition_fields()
                )
                SplunkDeferredORRegularExpression.reset()
                state.deferred[:] = remaining_deferred
                query = (
                    self.deferred_start
                    + self.deferred_separator.join(deferred_regex_or_expressions)
                    + "\n| search "
                    + query
                )

        return super().finish_query(rule, query, state)

    @staticmethod
    def _has_top_level_or(query: str) -> bool:
        """Return True if query contains an OR token outside of quotes and parentheses."""
        depth = 0
        in_quote = False
        escaped = False
        token = ""
        for c in query + " ":
            if in_quote:
                if escaped:
                    escaped = False
                elif c == "\\":
                    escaped = True
                elif c == '"':
                    in_quote = False
                continue
            if c == '"':
                in_quote = True
                token = ""
            elif c == "(":
                depth += 1
                token = ""
            elif c == ")":
                depth -= 1
                token = ""
            elif c.isspace():
                if token == "OR" and depth == 0:
                    return True
                token = ""
            else:
                token += c
        return False

    def finalize_query_default(
        self,
        rule: Union[SigmaRule, SigmaCorrelationRule],
        query: str,
        index: int,
        state: ConversionState,
    ) -> str:
        # When OR-ed regex expressions are deferred, extract leading field=value
        # conditions that don't depend on any deferred eval field and place them
        # before the deferred rex/eval pipeline commands. This ensures conditions
        # like index/source are at the beginning of the query for efficient
        # initial data retrieval.
        deferred_condition_fields = state.processing_state.get(
            "deferred_or_condition_fields"
        )
        search_marker = "\n| search "
        if deferred_condition_fields and search_marker in query:
            marker_idx = query.index(search_marker)
            deferred_part = query[:marker_idx]
            search_query = query[marker_idx + len(search_marker) :]

            prefix_parts = []
            pos = 0
            while pos < len(search_query):
                m = self._field_eq_val_re.match(search_query, pos)
                if m and m.group(1) not in deferred_condition_fields:
                    prefix_parts.append(m.group().strip())
                    pos = m.end()
                else:
                    break

            remaining_query = search_query[pos:]
            # Hoisting a term in front of the pipeline makes it a conjunct of the
            # whole search. That is only equivalent if the search expression is a
            # top-level conjunction; if it contains an OR outside of parentheses,
            # hoisting would move a term out of a disjunction branch, so the full
            # expression stays intact in the trailing | search stage.
            if prefix_parts and not self._has_top_level_or(search_query):
                prefix = " ".join(prefix_parts)
                query = prefix + deferred_part + search_marker + remaining_query

        if isinstance(rule, SigmaRule) and rule.fields:
            return (
                query
                + " | table "
                + ",".join(table_fields(rule.fields, self.field_quote, rule.source))
            )
        return query

    def finalize_query_savedsearches(
        self,
        rule: Union[SigmaRule, SigmaCorrelationRule],
        query: str,
        index: int,
        state: ConversionState,
    ) -> str:
        # remove brackets and line breaks from title: it becomes the stanza header
        clean_title = " ".join(
            _line_break_re.split(rule.title.translate({ord(c): None for c in "[]"}))
        )
        query_settings = self.query_settings(rule)
        query_settings["description"] = (
            rule.description.strip() if rule.description else ""
        )
        query_settings["search"] = query + (
            "\n| table "
            + ",".join(table_fields(rule.fields, self.field_quote, rule.source))
            if isinstance(rule, SigmaRule) and rule.fields
            else ""
        )

        return f"\n[{clean_title}]" + self._generate_settings(query_settings)

    def finalize_output_savedsearches(self, queries: List[str]) -> str:
        return (
            f"\n[default]"
            + self._generate_settings(self.output_settings)
            + "\n"
            + "\n".join(queries)
        )

    def convert_correlation_temporal_ordered_rule(
        self,
        rule: SigmaCorrelationRule,
        output_format: Optional[str] = None,
        method: str = "default",
    ) -> List[str]:
        """Convert a temporal_ordered correlation rule.

        Extends the temporal correlation by tracking the first occurrence time for each
        referenced event type and verifying events happened in the declared sequence order.
        """
        if method not in self.default_correlation_query:
            raise SigmaFeatureNotSupportedByBackendError(
                f"Correlation method '{method}' is not supported by backend for "
                "correlation type 'temporal_ordered'.",
                source=rule.source,
            )

        rule_ids = [rr.rule.name or str(rr.rule.id) for rr in rule.referenced_rules]
        for rid in rule_ids:
            check_identifier(rid, "rule name", rule.source)

        search = self.convert_correlation_search(rule)
        timespan = self.convert_timespan(rule.timespan, method)
        groupby = self.convert_correlation_aggregation_groupby_from_template(
            rule.group_by, method
        )
        fields_expr = self.convert_correlation_aggregation_fields_from_template(
            rule.fields, rule.referenced_rules, rule.group_by, method
        )

        # Generate per-rule first-occurrence stats. Field aliases use only word chars so
        # they are safe as unquoted Splunk field names in | where expressions.
        safe_ids = [re.sub(r"[^\w]", "_", rid) for rid in rule_ids]     # TODO: in Python 3.11 f-strings can't contain a backslash. If this Python version is deprecated, the code can be simplified.
        first_time_stats = "".join(
            f' earliest(eval(if(event_type="{rid}",_time,null())))'
            f" as first_{safe_id}"
            for rid, safe_id in zip(rule_ids, safe_ids)
        )

        aggregate = (
            f"| bin _time span={timespan}\n"
            f"| stats dc(event_type) as event_type_count"
            f"{fields_expr}{first_time_stats} by _time{groupby}"
        )

        cond_op = self.correlation_condition_mapping[rule.condition.op]
        condition = f"| search event_type_count {cond_op} {rule.condition.count}"

        if len(rule_ids) > 1:
            ordering = " AND ".join(
                f"first_{safe_ids[i]} < first_{safe_ids[i + 1]}"
                for i in range(len(safe_ids) - 1)
            )
            condition += f"\n| where {ordering}"

        return [
            self.default_correlation_query[method].format(
                search=search,
                aggregate=aggregate,
                condition=condition,
            )
        ]

    def finalize_query_data_model(
        self, rule: SigmaRule, query: str, index: int, state: ConversionState
    ) -> str:
        data_model = None
        data_set = None
        cim_fields = None
        if rule.logsource.product and rule.logsource.category:
            if rule.logsource.product == "windows":
                if rule.logsource.category == "process_creation":
                    data_model = "Endpoint"
                    data_set = "Processes"
                    cim_fields = " ".join(
                        splunk_sysmon_process_creation_cim_mapping.values()
                    )
                elif rule.logsource.category in [
                    "registry_add",
                    "registry_delete",
                    "registry_event",
                    "registry_set",
                ]:
                    data_model = "Endpoint"
                    data_set = "Registry"
                    cim_fields = " ".join(splunk_windows_registry_cim_mapping.values())
                elif rule.logsource.category == "file_event":
                    data_model = "Endpoint"
                    data_set = "Filesystem"
                    cim_fields = " ".join(
                        splunk_windows_file_event_cim_mapping.values()
                    )
            elif rule.logsource.product == "linux":
                if rule.logsource.category == "process_creation":
                    data_model = "Endpoint"
                    data_set = "Processes"
                    cim_fields = " ".join(
                        splunk_sysmon_process_creation_cim_mapping.values()
                    )

        elif rule.logsource.category == "proxy":
            data_model = "Web"
            data_set = "Proxy"
            cim_fields = " ".join(splunk_web_proxy_cim_mapping.values())

        elif rule.logsource.category == "network":
            if rule.logsource.service == "dns":
                data_model = "Network_Resolution"
                data_set = "DNS"
                cim_fields = " ".join(splunk_dns_cim_mapping.values())

        try:
            data_model_set = state.processing_state["data_model_set"]
        except KeyError:
            raise SigmaFeatureNotSupportedByBackendError(
                "No data model specified by processing pipeline"
            )

        if not data_model_set:
            raise SigmaFeatureNotSupportedByBackendError(
                "No data set specified by processing pipeline"
            )

        if "." in data_model_set:
            parts = data_model_set.split(".")
            if len(parts) != 2 or not all(parts):
                raise SigmaFeatureNotSupportedByBackendError(
                    "Expected format 'data_model.data_set', but got: {}".format(
                        data_model_set
                    )
                )
            data_set = parts[1]

        try:
            fields = " ".join(state.processing_state["fields"])
        except KeyError:
            raise SigmaFeatureNotSupportedByBackendError(
                "No fields specified by processing pipeline"
            )

        # Separate deferred expressions (regex/rex/eval/where) from the WHERE clause.
        # Deferred expressions cannot be placed inside a tstats WHERE clause.
        deferred_part = ""
        where_query = query

        # Handle OR regex deferred expressions prepended by finish_query.
        # Format: \n| rex ...\n| eval ...\n| search <query>
        search_marker = "\n| search "
        has_or_regex_deferred = search_marker in query
        if has_or_regex_deferred:
            marker_idx = query.index(search_marker)
            deferred_part = query[:marker_idx]
            where_query = query[marker_idx + len(search_marker) :]

        # Handle simple deferred expressions appended by the parent's finish_query.
        # Format: <query>\n| regex/where ...
        deferred_suffix_marker = "\n| "
        if deferred_suffix_marker in where_query:
            idx = where_query.index(deferred_suffix_marker)
            deferred_part += where_query[idx:]
            where_query = where_query[:idx]

        # Re-add the search command after deferred expressions for OR regex filtering
        if has_or_regex_deferred:
            deferred_part += search_marker + where_query

        summariesonly = self._data_model_summariesonly(state)
        aggregation = self._data_model_aggregation(state)
        time_prefix, span_suffix = self._data_model_span(state)

        return f"""| tstats summariesonly={summariesonly} allow_old_summaries=true fillnull_value="null" count min(_time) as firstTime max(_time) as lastTime{aggregation} from datamodel={data_model_set} where {where_query} by {time_prefix}{fields}{span_suffix}{deferred_part}
| `drop_dm_object_name({data_set})`
| convert timeformat="%Y-%m-%dT%H:%M:%S" ctime(firstTime)
| convert timeformat="%Y-%m-%dT%H:%M:%S" ctime(lastTime)
""".replace(
            "\n", " "
        )

    def _data_model_summariesonly(self, state: ConversionState) -> str:
        """Resolve tstats `summariesonly` from pipeline state, falling back to the backend option."""
        value = state.processing_state.get("summariesonly", self.summariesonly)
        if isinstance(value, str):
            normalized = value.strip().lower()
            if normalized in ("true", "t", "yes", "1"):
                return "true"
            if normalized in ("false", "f", "no", "0"):
                return "false"
            raise SigmaFeatureNotSupportedByBackendError(
                f"Invalid 'summariesonly' value for tstats data model query: {value!r}"
            )
        return self.bool_values[bool(value)]

    def _data_model_aggregation(self, state: ConversionState) -> str:
        """Render extra tstats aggregation functions from pipeline state, appended to the default count."""
        raw = state.processing_state.get("tstats_aggregation")
        if raw is not None:
            raw = str(raw).strip()
            return f" {raw}" if raw else ""
        specs = state.processing_state.get("tstats_aggregations")
        if not specs:
            return ""
        return "".join(
            f" {self._render_data_model_aggregation(spec)}" for spec in specs
        )

    def _render_data_model_aggregation(self, spec: Dict[str, str]) -> str:
        if not isinstance(spec, dict):
            raise SigmaFeatureNotSupportedByBackendError(
                f"Each 'tstats_aggregations' entry must be a mapping, got: {spec!r}"
            )
        func = str(spec.get("func", "")).strip().lower()
        if func not in self.data_model_aggregation_functions:
            raise SigmaFeatureNotSupportedByBackendError(
                f"Unsupported tstats aggregation function: {spec.get('func')!r}"
            )
        field = spec.get("field")
        if not field:
            raise SigmaFeatureNotSupportedByBackendError(
                f"tstats aggregation function '{func}' requires a 'field'"
            )
        field = str(field).strip()
        if not self._data_model_identifier_re.match(field):
            raise SigmaFeatureNotSupportedByBackendError(
                f"Invalid field name in 'tstats_aggregations': {field!r}"
            )
        token = f"{func}({field})"
        alias = spec.get("as") or spec.get("alias")
        if alias:
            alias = str(alias).strip()
            if not self._data_model_identifier_re.match(alias):
                raise SigmaFeatureNotSupportedByBackendError(
                    f"Invalid alias in 'tstats_aggregations': {alias!r}"
                )
            token += f" as {alias}"
        return token

    def _data_model_span(self, state: ConversionState) -> Tuple[str, str]:
        """Return the `_time`/`span=` fragments for tstats time bucketing from pipeline state."""
        span = state.processing_state.get("tstats_span")
        if span is None:
            return "", ""
        span = str(span).strip()
        if not self._data_model_span_re.match(span):
            raise SigmaFeatureNotSupportedByBackendError(
                f"Invalid 'tstats_span' value for tstats data model query: {span!r}"
            )
        return "_time ", f" span={span}"

    def finalize_output_data_model(self, queries: List[str]) -> List[str]:
        return queries
